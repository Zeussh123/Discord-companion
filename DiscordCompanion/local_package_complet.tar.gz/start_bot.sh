#!/bin/bash
echo "============================================="
echo "Demarrage du bot Discord de messages programmes"
echo "============================================="
echo ""
python3 discord_bot.py
echo ""
echo "Si le bot s'est arrete de maniere inattendue, verifiez les erreurs ci-dessus."